package kadhiravan;
 
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RestController;  
@RestController  

public class Restapi1   
{  
@RequestMapping("/")  
public String hello()   
{  
return "Hello World YEAH DONE";  
}  
}  