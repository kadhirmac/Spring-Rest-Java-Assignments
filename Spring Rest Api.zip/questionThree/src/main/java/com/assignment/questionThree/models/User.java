package com.assignment.questionThree.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document
public class User {
	
	@Id
	private String zip;
	@Field
	private String city;
	@Field
	private String state;
	@Field
	private String country;
	
	public User() {}
	
	public User(String zip,String city, String state, String country) {
		super();
		this.zip= zip;
		this.city = city;
		this.state = state;
		this.country = country;
	}





	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return String.format("User[zip='%s', city='%s', state='%s' , country='%s']", zip, city, state, country);
	}
	
	
}
