package com.assignment.questionThree;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PostMapping;

import com.assignment.questionThree.models.User;
import com.assignment.questionThree.repository.UserRepository;

@SpringBootApplication
public class QuestionThreeApplication implements CommandLineRunner{
	
	private final UserRepository userRepository;
	@Autowired
	public QuestionThreeApplication(UserRepository userRepository) {
		this.userRepository= userRepository;
	}
	public static void main(String[] args) {
		SpringApplication.run(QuestionThreeApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		
		if(userRepository.findAll().isEmpty()) {
			userRepository.save(new User("23425","City1","Arkansas","USA"));
			userRepository.save(new User("24624","City2","Missouri","USA"));
			userRepository.save(new User("25456","City3","Florida","USA"));
			userRepository.save(new User("26424","City4","Alabama","USA"));
			userRepository.save(new User("27566","City5","New Mexico","USA"));
		}
		
		for(User user: userRepository.findAll()) {
			System.out.println();
		}
	}
	
}
